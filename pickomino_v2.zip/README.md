# Pickomino
Proger pickomino université de paris goupe Option informatique
