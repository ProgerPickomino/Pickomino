
Fichiers d'execution
===

### Random.seed(3)
**seed3HumVsAle.txt** : fichier d'entree pour la commande python3 main.py < seed3HumVsAle.txt, *pour jouer une partie humain contre humain*
**seed3HumVsHum.txt** : fichier d'entree pour la commande python3 main.py < seed3HumVsHum.txt, *pour jouer une partie humain contre un joueur aleatoire*

### Random.seed(4) :
**seed4HumVsGlouton.txt** : fichier d'entree pour la commande python3 main.py < seed4HumVsGlouton.txt, *pour jouer une partie humain contre un joueur glouton*

